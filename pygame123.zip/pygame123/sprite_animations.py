import os.path
import time
import pygame
import sys
WIDTH, HEIGHT = 900, 500
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Hehe")
WHITE = (255,255,255)
BLACK = (0,0,0)
FPS = 60

class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        self.sprites = []
        self.is_animating = False

        self.sprites.append(pygame.image.load(os.path.join('game images', 'spaceships.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'black_rocket_exploding_1.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'black_rocket_exploding_2.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'black_rocket_exploding_3.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'black_rocket_exploding_4.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'black_rocket_exploding_5.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'black_rocket_exploding_6.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'black_rocket_exploding_7.png')))
        self.current_sprite = 0
        self.image = self.sprites[self.current_sprite]
        self.rect = self.image.get_rect()
        self.rect.topleft = [pos_x, pos_y]

    def animate(self):
        self.is_animating = True

    def update(self):
        if self.is_animating == True:
            self.current_sprite+=0.2
            if self.current_sprite >= len(self.sprites):
                self.current_sprite = 0
                self.is_animating = False

            self.image = self.sprites[int(self.current_sprite)]

class Player2(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        self.sprites = []
        self.is_animating = False

        self.sprites.append(pygame.image.load(os.path.join('game images', 'spaceships1.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'grey_rocket_exploding_1.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'grey_rocket_exploding_2.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'grey_rocket_exploding_3.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'grey_rocket_exploding_4.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'grey_rocket_exploding_5.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'grey_rocket_exploding_6.png')))
        self.sprites.append(pygame.image.load(os.path.join('game images', 'grey_rocket_exploding_7.png')))
        self.current_sprite = 0
        self.image = self.sprites[self.current_sprite]
        self.rect = self.image.get_rect()
        self.rect.topleft = [pos_x, pos_y]

    def animate(self):
        self.is_animating = True

    def update(self):
        if self.is_animating == True:
            self.current_sprite+=0.2
            if self.current_sprite >= len(self.sprites):
                self.current_sprite = 0
                self.is_animating = False

            self.image = self.sprites[int(self.current_sprite)]


moving_sprites = pygame.sprite.Group()
player = Player(100,100)
moving_sprites.add(player)

moving_sprites2 = pygame.sprite.Group()
player2 = Player2(250,250)
moving_sprites2.add(player2)



def draw_window():
    pass
def main():
    clock  = pygame.time.Clock()
    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.KEYDOWN:
                player.animate()
                player2.animate()
        WIN.fill(BLACK)
        moving_sprites.draw(WIN)
        moving_sprites.update()
        moving_sprites2.draw(WIN)
        moving_sprites2.update()
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
