import os
import pygame
pygame.font.init()
pygame.mixer.init()

HEIGHT, WIDTH = 500, 900
SPACESHIP_HEIGHT, SPACESHIP_WIDTH = 68, 62
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("BIG BOYS")

HEALTH_FONT = pygame.font.SysFont('comicsans', 40)
WINNER_FONT = pygame.font.SysFont('comicsans', 40)

white_images = [pygame.transform.rotate(pygame.image.load(os.path.join("game images", "grey_rocket_exploding_1.png")), 180),
         pygame.transform.rotate(pygame.image.load(os.path.join("game images", "grey_rocket_exploding_2.png")),180),
         pygame.transform.rotate(pygame.image.load(os.path.join("game images", "grey_rocket_exploding_3.png")), 180),
         pygame.transform.rotate(pygame.image.load(os.path.join("game images", "grey_rocket_exploding_4.png")),180),
         pygame.transform.rotate(pygame.image.load(os.path.join("game images", "grey_rocket_exploding_5.png")),180),
         pygame.transform.rotate(pygame.image.load(os.path.join("game images", "grey_rocket_exploding_6.png")),180),
         pygame.transform.rotate(pygame.image.load(os.path.join("game images", "grey_rocket_exploding_7.png")),180)]

black_images = [pygame.image.load(os.path.join("game images", "black_rocket_exploding_1.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_2.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_3.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_4.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_5.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_6.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_7.png"))]

white_explosion = False
black_explosion = False
stepIndex = 0

WHITE = (255,255,255)
BLACK = (0,0,0)
RED = (255, 40, 0)
PURP = (226, 0 ,143)
FPS = 60
VEL = 5
BULLET_VEL = 7
MAX_BULLETS = 3
BORDER = pygame.Rect(WIDTH//2 - 5, 0, 10, HEIGHT )


BLACK_HIT = pygame.USEREVENT + 1
WHITE_HIT = pygame.USEREVENT + 2

white_spaceship = pygame.image.load(os.path.join('game images', 'spaceships1.png'))
black_spaceship = pygame.image.load(os.path.join('game images', 'spaceships.png'))
SPACE = pygame.transform.scale(pygame.image.load(os.path.join('game images', 'space.jpg')), (WIDTH, HEIGHT))


white_spaceship2 = pygame.transform.rotate(pygame.transform.scale(white_spaceship, (SPACESHIP_HEIGHT,SPACESHIP_WIDTH)), 180)
black_spaceship2 = pygame.transform.scale(black_spaceship, (SPACESHIP_HEIGHT,SPACESHIP_WIDTH))




def draw_window(white, black, black_bullets, white_bullets, black_health, white_health):
    WIN.blit(SPACE, (0,0))


    black_health_text = HEALTH_FONT.render("Health:" + str(black_health), 1, WHITE)
    white_health_text = HEALTH_FONT.render("Health:" + str(white_health), 1, WHITE)
    WIN.blit(white_health_text, (WIDTH - white_health_text.get_width()-10, 10))
    WIN.blit(black_health_text, (10,10))

    pygame.draw.rect(WIN, BLACK, BORDER)
    WIN.blit(black_spaceship2, (black.x,black.y))
    WIN.blit(white_spaceship2, (white.x,white.y))


    for bullet in black_bullets:
        pygame.draw.rect(WIN, PURP, bullet)

    for bullet in white_bullets:
        pygame.draw.rect(WIN, RED, bullet)

    global stepIndex
    global white_explosion
    global black_explosion
    if white_explosion:
        white_spaceship2.set_alpha(0)
        WIN.blit(white_images[stepIndex//4], (white.x, white.y))
        stepIndex += 1

    elif black_explosion:
        black_spaceship2.set_alpha(0)
        WIN.blit(black_images[stepIndex//4], (black.x,black.y))
        stepIndex += 1

    pygame.display.update()



def black_movement(keys_pressed, black):
    if keys_pressed[pygame.K_a] and black.x - VEL > 0:
        black.x -= VEL
    if keys_pressed[pygame.K_d] and black.x + VEL + black.width < BORDER.x:
        black.x += VEL
    if keys_pressed[pygame.K_w] and black.y - VEL > 0:
        black.y -= VEL
    if keys_pressed[pygame.K_s] and black.y + VEL + black.height < HEIGHT:
        black.y += VEL

def white_movement(keys_pressed, white):
    if keys_pressed[pygame.K_LEFT] and white.x - VEL > BORDER.x + BORDER.width:  # left
        white.x -= VEL
    if keys_pressed[pygame.K_RIGHT] and white.x + VEL + white.width < WIDTH:
        white.x += VEL
    if keys_pressed[pygame.K_UP] and white.y - VEL > 0:  # left
        white.y -= VEL
    if keys_pressed[pygame.K_DOWN] and white.y + VEL + white.height < HEIGHT:
        white.y += VEL
def handle_bullets(black_bullets, white_bullets, black, white):
    for bullet in black_bullets:
        bullet.x += BULLET_VEL
        if white.colliderect(bullet):
            pygame.event.post(pygame.event.Event(WHITE_HIT))
            black_bullets.remove(bullet)
        elif bullet.x > WIDTH:
            black_bullets.remove(bullet)
    for bullet in white_bullets:
        bullet.x -= BULLET_VEL
        if black.colliderect(bullet):
            pygame.event.post(pygame.event.Event(BLACK_HIT))
            white_bullets.remove(bullet)
        elif bullet.x < 0:
            white_bullets.remove(bullet)



def draw_winner(text):
    draw_text = WINNER_FONT.render(text,1,WHITE)
    WIN.blit(draw_text, (WIDTH/2- draw_text.get_width()/2, HEIGHT/2 - draw_text.get_height()/2))
    pygame.display.update()
    pygame.time.delay(5000)

def main():
    white = pygame.Rect(700, 100, SPACESHIP_HEIGHT, SPACESHIP_WIDTH )
    black = pygame.Rect(100, 100, SPACESHIP_HEIGHT, SPACESHIP_WIDTH )

    clock = pygame.time.Clock()
    black_bullets = []
    white_bullets = []
    black_health = 10
    white_health = 10
    white_spaceship2.set_alpha(255)
    black_spaceship2.set_alpha(255)



    global stepIndex
    global white_explosion
    global black_explosion

    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r and len(black_bullets) < MAX_BULLETS:
                    bullet = pygame.Rect(black.x + black.width, black.y + black.height//2 -2, 10,5 )
                    black_bullets.append(bullet)

                if event.key == pygame.K_RCTRL and len(white_bullets) < MAX_BULLETS:
                    bullet = pygame.Rect(white.x, white.y + white.height//2 - 2, 10, 5)
                    white_bullets.append(bullet)
            if event.type == BLACK_HIT:
                black_health -= 1
            if event.type == WHITE_HIT:
                white_health -= 1
        winner_text = ""
        if black_health <= 0:
            white_explosion = False
            black_explosion = True




        if black_explosion and stepIndex >=28:
            winner_text = "WHITE WINS!"
        if white_explosion and stepIndex >=28:
            winner_text = "BLACK WINS!"


        if white_health <=0:
            white_explosion = True
            black_explosion = False

        if stepIndex >= 28:
            black_explosion = False
            white_explosion = False
            stepIndex = 0


        if winner_text != "":
            draw_winner(winner_text)
            break








        keys_pressed = pygame.key.get_pressed()
        white_movement(keys_pressed, white)
        black_movement(keys_pressed, black)
        handle_bullets(black_bullets, white_bullets, black, white)
        draw_window(white, black, black_bullets, white_bullets, black_health, white_health)


    main()
if __name__ == "__main__":
    main()