import pygame
import os

pygame.init()
win = pygame.display.set_mode((500, 500))

# Load Images of the Character (there are two popular ways)
stationary = pygame.image.load(os.path.join("game images", "spaceships.png"))
stationary2 = pygame.image.load(os.path.join("game images", "spaceships1.png"))
# One way to do it - using the sprites that face left.
left =  [pygame.image.load(os.path.join("game images", "grey_rocket_exploding_1.png")),
         pygame.image.load(os.path.join("game images", "grey_rocket_exploding_2.png")),
         pygame.image.load(os.path.join("game images", "grey_rocket_exploding_3.png")),
         pygame.image.load(os.path.join("game images", "grey_rocket_exploding_4.png")),
         pygame.image.load(os.path.join("game images", "grey_rocket_exploding_5.png")),
         pygame.image.load(os.path.join("game images", "grey_rocket_exploding_6.png")),
         pygame.image.load(os.path.join("game images", "grey_rocket_exploding_7.png"))]

right = [pygame.image.load(os.path.join("game images", "black_rocket_exploding_1.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_2.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_3.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_4.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_5.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_6.png")),
         pygame.image.load(os.path.join("game images", "black_rocket_exploding_7.png"))]



x = 250
y = 250
vel = 10
white_explosion = False
black_explosion = False
stepIndex = 0

# Draw the Game
def draw_game():
    global stepIndex
    win.fill((0, 0, 0))

    if white_explosion:
        win.blit(left[stepIndex//4], (x, y))
        stepIndex += 1

    elif black_explosion:
        win.blit(right[stepIndex//4], (x,y))
        stepIndex += 1
    else:
        win.blit(stationary, (x,y))


# Main Loop
run = True
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    draw_game()

    # Movement
    userInput = pygame.key.get_pressed()
    if userInput[pygame.K_LEFT]:

        white_explosion = True
        black_explosion = False
    elif userInput[pygame.K_RIGHT]:

        white_explosion = False
        black_explosion = True

    if stepIndex >= 28:
        black_explosion = False
        white_explosion = False
        stepIndex = 0


    pygame.time.delay(30)
    pygame.display.update()